AskMe Forum

This project was created for the Advanced Topics on Web Engineering course at UBT.
It is a small forum application where users can register, login, ask questions, and answer questions.

Features

Register/Login with email and password (data stored in users.json on the backend)

Full authentication with state management on the frontend

Automatic login after browser refresh or close (user stored in localStorage)

Only logged-in users can post new questions

Visitors can post answers (name required, email optional)

Questions include:

Title – the main question title

Description – detailed content of the question

Tags – keywords related to the question

Category – selected from a drop-down list

Author – user who posted the question

Type – a drop-down field to classify the question

View counter – tracks how many times the question has been viewed

Answers include:

Name – the person answering

Email – optional email of the answerer

Answer content – the main response

References – optional field to add links or sources

Edit and Delete functionality for both questions and answers

Frontend refactored into reusable components for cleaner, maintainable code

Architecture

Two microservices:

Forum Service (port 5000) → handles questions, answers, and views

Users Service (port 5001) → handles registration, login, and user storage in users.json

Built with React (Vite) frontend and Node.js/Express backend

Version control with GitHub

Frontend Refactoring & Components

The main goal of refactoring the frontend was to separate logic into smaller, reusable, and maintainable components, while implementing full authentication and proper state management.

Components include:

Header, Footer – layout and navigation

AuthSection – handles login and registration

AskQuestionForm – form for adding new questions

QuestionsList – displays all questions

QuestionDetails – shows details of a single question and its answers

Example – AskQuestionForm:
Props:

currentUser – checks if a user is logged in

questionForm – stores the question data

questionMsg – success/error message

categoriesForForm – list of categories

handleQuestionChange – updates form inputs

submitQuestion – sends the question to the backend

This structure makes the code cleaner and easier to maintain.

Authentication with Password

Authentication is implemented using email and password. Credentials are sent via POST requests to the backend and verified.

Login Persistence (localStorage)

After login, the user is saved in localStorage. A useEffect hook restores the user automatically when the app reloads.

State Management – Why useState

useState is used to store dynamic data such as the current user, questions, answers, and form data. It ensures the UI updates automatically when state changes.

Why State Exists in Both Frontend and Backend

Frontend state → used for UI rendering

Backend state → stores actual data (like a database)
This separation improves security and stability.

New Additions

References in answers → stored in state and sent to the backend

Type field in questions → implemented as a drop-down in the form

Edit/Delete functionality → for both questions and answers