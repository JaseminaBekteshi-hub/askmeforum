// ======================== IMPORTET ========================
// Importojmë libraritë kryesore për serverin
const express = require('express');   // Krijon serverin
const cors = require('cors');         // Lejon kërkesa nga frontend-i
const fs = require('fs');             // Për lexim/shkrim në file
const path = require('path');         // Punon me rrugë të file-ve

// ======================== KRIJIMI I APP ========================
const app = express();
app.use(cors());              // Aktivizo CORS
app.use(express.json());      // Lejon JSON në request body

// ======================== FILE KU RUHEN USERAT ========================
// users.json ruan të gjithë përdoruesit
const USERS_FILE = path.join(__dirname, 'users.json');

// Lexon user-at nga file
function loadUsers() {
  try {
    const raw = fs.readFileSync(USERS_FILE, 'utf8');
    return JSON.parse(raw);     // Kthen listën ekzistuese
  } catch {
    return [];                  // Nëse file nuk ekziston, kthen listë bosh
  }
}

// Ruaj user-at në file
function saveUsers(list) {
  fs.writeFileSync(USERS_FILE, JSON.stringify(list, null, 2));
}

// Lista e userave në memorie
let users = loadUsers();

// ======================== ROUTE: TEST SERVER ========================
// Kontroll për të parë nëse serveri punon
app.get('/', (_req, res) => res.send('Users service is running (5001)'));

// ======================== REGISTER ========================
// Regjistrimi i një përdoruesi të ri
app.post('/api/users/register', (req, res) => {
  const { name, surname, email, password } = req.body || {};

  // Validime bazë
  if (!name || !email || !surname)
    return res.status(400).json({ error: 'Name and email are required.' });

  // Kontrollo nëse ekziston email-i
  const exists = users.some(u =>
    String(u.email).toLowerCase() === String(email).toLowerCase()
  );
  if (exists)
    return res.status(400).json({ error: 'A user with this email already exists.' });

  // Krijo user të ri
  const newUser = {
    id: users.length ? Math.max(...users.map(u => u.id)) + 1 : 1,  // Rrit ID-n
    name: String(name).trim(),
    surname: String(surname).trim(),
    email: String(email).trim(),
    createdAt: new Date().toISOString(),
  };

  users.push(newUser);   // Shto në listë
  saveUsers(users);      // Ruaj në file

  res.json(newUser);     // Kthe userin e krijuar
});

// ======================== LOGIN ========================
// Hyrja e një përdoruesi ekzistues
app.post('/api/users/login', (req, res) => {
  const { email } = req.body || {};

  if (!email)
    return res.status(400).json({ error: 'Email is required.' });

  // Kërkon përdoruesin me atë email
  const user = users.find(u =>
    String(u.email).toLowerCase() === String(email).toLowerCase()
  );

  if (!user)
    return res.status(404).json({ error: 'No user found with this email. Please register.' });

  res.json({ id: user.id, name: user.name, surname: user.surname, email: user.email });
});

// ======================== GET USERS ========================
// Kthen listën e të gjithë përdoruesve
app.get('/api/users', (_req, res) => res.json(users));

// ======================== START SERVER ========================
const PORT = 5001;
app.listen(PORT, () => {
  console.log(`Users service listening on http://localhost:${PORT}`);
});
