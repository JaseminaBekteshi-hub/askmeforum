// ======================== IMPORTET ========================
// Express: krijon serverin
const express = require('express');  
// CORS: lejon frontend-in (5173) të komunikojë me backend-in (4000)
const cors = require('cors');        

// ======================== KRIJIMI I APP ========================
const app = express();
const PORT = 4000;

// Middleware kryesor
app.use(cors());            // Lejon kërkesat nga frontend-i
app.use(express.json());    // Lejon JSON në request body

// ======================== PYETJE STATIKE ========================
// Pyetje të krijuara manualisht (deri sa të përdoren file ose DB)
let questions = [
  {
    id: 1,
    title: "How to install Node.js?",
    description: "I am new to JavaScript. Can someone explain how to install Node.js?",
    category: "Technology",
    tags: ["nodejs", "javascript"],
    author: "Alice",
    views: 3,
    createdAt: new Date().toISOString()
  },
  {
    id: 2,
    title: "What is React?",
    description: "Can someone explain React in simple words?",
    category: "Web Development",
    tags: ["react", "frontend"],
    author: "Bob",
    views: 5,
    createdAt: new Date().toISOString()
  }
];

// Lista ku ruhen të gjitha përgjigjet
let answers = [];

// ======================== ROUTES ========================

// Test: kontrollon nëse serveri punon
app.get('/', (req, res) => {  
  res.send('The server for questions and answers is running');
});

// Kthen të gjitha pyetjet
app.get('/api/questions', (req, res) => {  
  res.json(questions);
});

// Kthen një pyetje sipas ID dhe rrit numrin e shikimeve
app.get('/api/questions/:id', (req, res) => {
  const id = Number(req.params.id);
  const q = questions.find(q => q.id === id);

  if (!q) {
    return res.status(404).json({ error: 'Question not found' });
  }

  q.views += 1;       // rrit views sa herë hapet pyetja
  res.json(q);
});

// Krijon një pyetje të re
app.post('/api/questions', (req, res) => {
  let { title, description, category, tags, author, type } = req.body;

  // Validim fushash
  if (!title || !description || !category || !author || !type) {
    return res.status(400).json({ error: 'Please fill: title, description, category, author and type' });
  }

  // Tags mund të dërgohen si string → i kthejmë në listë
  if (typeof tags === 'string') {
    tags = tags.split(',').map(t => t.trim()).filter(Boolean);
  }
  if (!Array.isArray(tags)) tags = [];

  // Krijojmë objektin e pyetjes së re
  const newQuestion = {
    id: questions.length ? Math.max(...questions.map(q => q.id)) + 1 : 1, // gjenerim ID
    title,
    description,
    category,
    tags,
    author,
    type,
    views: 0, 
    createdAt: new Date().toISOString()
  };

  questions.push(newQuestion);  // Ruhet në memorie
  res.status(201).json(newQuestion);
});

// Kthen të gjitha përgjigjet për një pyetje të caktuar
app.get('/api/questions/:id/answers', (req, res) => {
  const qid = Number(req.params.id);
  const list = answers.filter(a => a.questionId === qid);
  res.json(list);
});

// Shton një përgjigje të re në një pyetje
app.post('/api/questions/:id/answers', (req, res) => {
  const qid = Number(req.params.id);
  const { author, email, text, references } = req.body;

  // Validim i përgjigjes
  if (!author || !text) {
    return res.status(400).json({ error: 'Please provide your name and answer text.' });
  }

  // Kontrollo nëse ekziston pyetja
  const exists = questions.some(q => q.id === qid);
  if (!exists) {
    return res.status(404).json({ error: 'Question not found.' });
  }

  // Krijon përgjigjen e re
  const newAnswer = {
    id: answers.length ? Math.max(...answers.map(a => a.id)) + 1 : 1,
    questionId: qid,
    author,
    email: email || '',
    text,
    references: references || '',
    createdAt: new Date().toISOString()
  };

  answers.push(newAnswer); // Ruhet në memorie
  res.status(201).json(newAnswer);
});

// ================= DELETE QUESTION =================
app.delete('/api/questions/:id', (req, res) => {

  const id = Number(req.params.id);

  questions = questions.filter(q => q.id !== id);

  res.json({ message: 'Question deleted' });

});


// ================= EDIT QUESTION =================
app.put('/api/questions/:id', (req, res) => {

  const id = Number(req.params.id);
  const { title, description, category, tags, type } = req.body;

  const q = questions.find(q => q.id === id);

  if (!q) {
    return res.status(404).json({ error: 'Question not found' });
  }

  q.title = title || q.title;
  q.description = description || q.description;
  q.category = category || q.category;
  q.type= type || q.type;

  if (tags) {
    if (typeof tags === "string") {
      q.tags = tags.split(",").map(t => t.trim());
    } else {
      q.tags = tags;
    }
  }

  res.json({ message: 'Question updated', question: q });

});

// ================= DELETE ANSWER =================
app.delete('/api/answers/:id', (req, res) => {

  const id = Number(req.params.id);

  answers = answers.filter(a => a.id !== id);

  res.json({ message: 'Answer deleted' });

});



// ================= EDIT ANSWER =================
app.put('/api/answers/:id', (req, res) => {

  const id = Number(req.params.id);
  const { author, email, text, references } = req.body;

  const a = answers.find(a => a.id === id);

  if (!a) {
    return res.status(404).json({ error: 'Answer not found' });
  }

  a.author = author || a.author;
  a.email = email || a.email;
  a.text = text || a.text;
  a.references = references || a.references;

  res.json({ message: 'Answer updated', answer: a });

});



// ======================== START SERVER ========================
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
