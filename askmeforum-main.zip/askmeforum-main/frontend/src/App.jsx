import { useEffect, useState } from "react";
import Header from "./components/Header";
import Footer from "./components/Footer";
import AuthSection from "./components/AuthSection";
import AskQuestionForm from "./components/AskQuestionForm";
import QuestionsList from "./components/QuestionsList";
import QuestionDetails from "./components/QuestionDetails";
import useAuth from "./hooks/useAuth";
import "./App.css";

const askme_API = "http://localhost:4000";

const categoriesForForm = [
  "Technology",
  "Web Development",
  "Business",
  "General",
  "Other",
];

const typeForForm = [
  "Test1",
  "Test2",
  
];

function App() {
  // ================= QUESTION FORM =================
  const [questionForm, setQuestionForm] = useState({
    title: "",
    description: "",
    category: "General",
    tags: "",
    author: "",
    type: "All",
  });

  // ================= AUTH =================
  const {
    currentUser,
    registerForm,
    loginForm,
    authMsg,
    handleRegisterChange,
    handleLoginChange,
    registerUser,
    loginUser,
    logout,
  } = useAuth(setQuestionForm);  // AUTORI NE FORMEN E PYETJES

// typeFilter,settypeFilter,typesForFilter,


  // ================= QUESTIONS =================
  const [questions, setQuestions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [typeFilter, settypeFilter] = useState("All");
  const [questionMsg, setQuestionMsg] = useState("");

  const [answerForm, setAnswerForm] = useState({
    author: "",
    email: "",
    text: "",
    references: "",
  });

  // ================= FETCH QUESTIONS =================
  const loadQuestions = async () => {
    try {
      const res = await fetch(`${askme_API}/api/questions`);
      const data = await res.json();
      setQuestions(Array.isArray(data) ? data : []);
    } catch {}
  };

  useEffect(() => {
    loadQuestions();
  }, []);

  // ================= FILTER =================
  const filteredQuestions =
    categoryFilter === "All"
      ? questions
      : questions.filter((q) => q.category === categoryFilter);

      
 const filteredQuestionsByType =
  typeFilter === "All"
    ? filteredQuestions
    : filteredQuestions.filter((q) => q.type === typeFilter);
  // ================= QUESTION HANDLERS =================


  const handleQuestionChange = (e) =>
    setQuestionForm((p) => ({ ...p, [e.target.name]: e.target.value }));

  const submitQuestion = async (e) => {
    e.preventDefault();
    if (!currentUser) {
      setQuestionMsg("Please login first.");
      return;
    }

    try {
      await fetch(`${askme_API}/api/questions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...questionForm,
          author: currentUser.name,
        }),
      });

      setQuestionMsg("Question posted ✅");
      setQuestionForm({
        title: "",
        description: "",
        category: "General",
        tags: "",
        author: currentUser.name,
        type:"All"
        

      });

      loadQuestions();
    } catch {}
  };

  // ================= OPEN QUESTION =================
  const openQuestion = async (id) => {
    try {
      const res = await fetch(`${askme_API}/api/questions/${id}`);
      const q = await res.json();
      setSelected(q);
      loadAnswers(id);
    } catch {}
  };

  // ================= ANSWERS =================
 const loadAnswers = async (qid) => {
  try {
    const res = await fetch(
      `${askme_API}/api/questions/${qid}/answers`
    );
    const data = await res.json();
    setAnswers(Array.isArray(data) ? data : []);
  } catch {}
};

  const handleAnswerChange = (e) =>
    setAnswerForm((p) => ({ ...p, [e.target.name]: e.target.value }));

  const submitAnswer = async (e) => {
    e.preventDefault();
    if (!selected) return;

    try {
      await fetch(
        `${askme_API}/api/questions/${selected.id}/answers`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(answerForm),
        }
      );

      setAnswerForm({ author: "", email: "", text: "", references: "" });
      loadAnswers(selected.id);
    } catch {}
  };

// ================= DELETE QUESTION =================
const deleteQuestion = async (id) => {

  const confirmDelete = window.confirm("Are you sure you want to delete this question?");

  if (!confirmDelete) return;

  try {
    await fetch(`${askme_API}/api/questions/${id}`, {
      method: "DELETE",
    });

    loadQuestions();

  } catch (err) {
    console.log(err);
  }
};

// ================= EDIT QUESTION =================
const editQuestion = async (id) => {

  const newTitle = prompt("Edit title");
  const newDescription = prompt("Edit description");
  const newCategory = prompt("Edit category");
  const newTags = prompt("Edit tags (comma separated)");
  const newType = prompt("Edit Type");

  if (!newTitle || !newDescription || !newCategory || !newType) return;

  try {
    await fetch(`${askme_API}/api/questions/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title: newTitle,
        description: newDescription,
        category: newCategory,
        tags: newTags,
        type: newType
      }),
    });

    loadQuestions();

  } catch (err) {
    console.log(err);
  }
};

// ================= DELETE ANSWER =================
const deleteAnswer = async (id) => {

  const confirmDelete = window.confirm("Are you sure you want to delete this answer?");

  if (!confirmDelete) return;


  try {
    await fetch(`${askme_API}/api/answers/${id}`, {
      method: "DELETE",
    });

    loadAnswers(selected.id);
  } catch (err) {
    console.log(err);
  }
};

// ================= EDIT ANSWER =================
const editAnswer = async (answer) => {

  const newAuthor = prompt("Edit Name", answer.author);
  const newEmail = prompt("Edit Email", answer.email);
  const newText = prompt("Edit Answer", answer.text);
  const newReferences = prompt("Edit References", answer.references);

  if (!newAuthor || !newText) return;

  try {
    await fetch(`${askme_API}/api/answers/${answer.id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        author: newAuthor,
        email: newEmail,
        text: newText,
        references: newReferences,
      }),
    });

    loadAnswers(selected.id);

  } catch (err) {
    console.log(err);
  }
};




  const backToList = () => {
    setSelected(null);
    setAnswers([]);
  };

  // ================= RENDER =================Kjo pjesë vendos çfarë shfaqet në ekran
  return (
    <div className="container">
      <Header />

      <AuthSection
        currentUser={currentUser}
        registerForm={registerForm}
        loginForm={loginForm}
        authMsg={authMsg}
        handleRegisterChange={handleRegisterChange}
        handleLoginChange={handleLoginChange}
        registerUser={registerUser}
        loginUser={loginUser}
        logout={logout}
      />

      {selected ? (
        //Është state që ruan pyetjen e zgjedhur
        <QuestionDetails
  selected={selected}
  answers={answers}
  answerForm={answerForm}
  handleAnswerChange={handleAnswerChange}
  submitAnswer={submitAnswer}
  goBack={backToList}
  deleteAnswer={deleteAnswer}
  editAnswer={editAnswer}
/>
      ) : (
        <>
          <AskQuestionForm
            currentUser={currentUser}
            questionForm={questionForm}
            questionMsg={questionMsg}
            categoriesForForm={categoriesForForm}
            typeForForm={typeForForm}
            handleQuestionChange={handleQuestionChange}
            submitQuestion={submitQuestion}
          />
<QuestionsList
  questions={filteredQuestionsByType}
  categoryFilter={categoryFilter}
  setCategoryFilter={setCategoryFilter}
  categoriesForFilter={["All", ...categoriesForForm]}

  typeFilter={typeFilter}
  settypeFilter={settypeFilter}
  typesForFilter={["All", ...typeForForm]}

  openQuestion={openQuestion}
  deleteQuestion={deleteQuestion}
  editQuestion={editQuestion}
/>
        </>
      )}

      <Footer />
    </div>
  );
}

export default App;
