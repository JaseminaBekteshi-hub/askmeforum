const AskQuestionForm = ({
  currentUser,
  questionForm,
  questionMsg,
  categoriesForForm,
  typeForForm,
  handleQuestionChange,
  submitQuestion,
}) => {
  return (
    <section className="card">
      <h2 className="section-title">Ask a Question</h2>

      <p className="small" style={{ marginTop: -6 }}>
        Only <strong>logged-in (registered)</strong> users can post questions.
        Visitors can answer any question.
      </p>

      <form onSubmit={submitQuestion}>
        <label className="label">Title</label>
        <input
          className="input"
          name="title"
          value={questionForm.title}
          onChange={handleQuestionChange}
        />
        <div style={{ height: 10 }} />

        <label className="label">Description</label>
        <textarea
          className="textarea"
          name="description"
          value={questionForm.description}
          onChange={handleQuestionChange}
        />
        <div style={{ height: 10 }} />

        
<label className="label">Tags (comma separated)</label>
        <input
          className="input"
          name="tags"
          value={questionForm.tags}
          onChange={handleQuestionChange}
          placeholder="react, javascript"
        />
        <div style={{ height: 10 }} />



        <label className="label">Category</label>
        <select
          className="select"
          name="category"
          value={questionForm.category}
          onChange={handleQuestionChange}
        >
          {categoriesForForm.map(c => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <div style={{ height: 10 }} />

        

        <label className="label">Author</label>
        <input
          className="input"
          name="author"
          value={questionForm.author}
          readOnly
          placeholder="Login to fill"
        />
        <div style={{ height: 12 }} />
 
 
 <label className="label">Type</label>
<select
  className="select"
  name="type"
  value={questionForm.type}
  onChange={handleQuestionChange}
>
  {typeForForm.map((t) => (
    <option key={t} value={t}>
      {t}
    </option>
  ))}
</select>

<div style={{ height: 10 }} />



        <button
          type="submit"
          className="btn"
          disabled={!currentUser  }

        >
          Post Question
        </button>
      </form>

      {questionMsg && (
        <p className="small" style={{ marginTop: 12 }}>
          {questionMsg}
        </p>
      )}
    </section>
  );
};

export default AskQuestionForm;
