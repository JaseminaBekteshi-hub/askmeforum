import LoginForm from "./LoginForm";
import RegisterForm from "./RegisterForm";



function AuthSection({
  currentUser,
  loginForm,
  registerForm,
  authMsg,
  handleLoginChange,
  handleRegisterChange,
  loginUser,
  registerUser,
  logout,
}) {
  return (
    <section className="auth-section">
      {authMsg && <p className="auth-msg">{authMsg}</p>}

      {!currentUser ? (
        <>
          <RegisterForm
            registerForm={registerForm}
            handleRegisterChange={handleRegisterChange}
            registerUser={registerUser}
          />

          <LoginForm
            loginForm={loginForm}
            handleLoginChange={handleLoginChange}
            loginUser={loginUser}
          />
        </>
      ) : (
        <>
          <p>Logged in as: <b>{currentUser.name}</b></p>
          <button onClick={logout} >Logout</button>
          
        </>
      )}
    </section>
  );
}

export default AuthSection;
