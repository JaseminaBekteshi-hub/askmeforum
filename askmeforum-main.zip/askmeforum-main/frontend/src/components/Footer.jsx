const Footer = () => {
  return (
    <footer className="footer">
      © 2025 AskMe Forum | Built by Jasemina & Ernesa
    </footer>
  );
};

export default Footer;
