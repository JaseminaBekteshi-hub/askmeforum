const Header = () => {
  return (
    <header className="header">
      <h1>AskMe – Forum</h1>
      <p className="tagline">
        A collaborative space for technical discussions.<br />
        Registered users can post questions, and visitors are welcome to share their answers.
      </p>
    </header>
  );
};

export default Header;
