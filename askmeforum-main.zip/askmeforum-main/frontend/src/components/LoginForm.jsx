function LoginForm({
  loginForm,
  handleLoginChange,
  loginUser,
}) {
  return (
    <section className="auth-card">
      <h3>Login</h3>

      <form className="auth-form" onSubmit={loginUser}>
        <input
          type="email"
          name="email"
          required
          placeholder="Email"
          value={loginForm.email}
          onChange={handleLoginChange}
          
        />
      

        <input
          type="password"
          name="password"
          placeholder="Password"
          value={loginForm.password}
          onChange={handleLoginChange}
        />

        <button type="submit" >Login</button>
      </form>
    </section>
  );
}

export default LoginForm;
