import React from 'react';

const QuestionDetails = ({
  selected,
  answers = [],
  answerForm,
  handleAnswerChange,
  submitAnswer,
  goBack,
  deleteAnswer,
  editAnswer,
}) => {
  // ⛑️ GUARD – parandalon crash kur selected është null / undefined
  if (!selected) return null;

  return (
    <section className="card">
      {/* BACK BUTTON */}
      <button
        onClick={goBack}
        className="btn"
        style={{ marginBottom: 12 }}
      >
        ← Back
      </button>

      {/* QUESTION DETAILS */}
      <h2 style={{ margin: '6px 0 8px' }}>{selected.title}</h2>
      <p>{selected.description}</p>

      <p className="small">
        Category: {selected.category} | Author: {selected.author} | Views:{' '}
        {selected.views}
        {selected.tags && (
          <>
            {' '}
            | Tags:{' '}
            {Array.isArray(selected.tags)
              ? selected.tags.join(', ')
              : selected.tags}
          </>
        )}
      </p>

      <hr className="divider" />

      {/* ANSWERS LIST */}
      <h3 className="section-title" style={{ marginTop: 0 }}>
        Answers
      </h3>

      {answers.length === 0 ? (
        <p className="small">No answers yet. Be the first to answer!</p>
      ) : (
      answers.map((a) => (
  <div key={a.id} className="answer">
    <strong>{a.author}</strong>
    {a.email ? ` (${a.email})` : ""}: {a.text}

    <div className="small">
      {new Date(a.createdAt).toLocaleString()}
    </div>

    {/* BUTTONS EDIT & DELETE */}
    <div style={{ marginTop: 8 }}>
      <button
        className="btn"
        onClick={() => editAnswer(a)}
      >
        Edit
      </button>

      <button
        className="btn"
        style={{ marginLeft: 6, background: "red", color: "white" }}
        onClick={() => deleteAnswer(a.id)}
      >
        Delete
      </button>
    </div>

  </div>
))
      )}

      <hr className="divider" />

      {/* ADD ANSWER FORM */}
      <h3 className="section-title">Add your answer</h3>

      <form onSubmit={submitAnswer}>
        <label className="label">Your name</label>
        <input
          className="input"
          name="author"
          value={answerForm.author}
          onChange={handleAnswerChange}
        />
        <div style={{ height: 10 }} />

        <label className="label">Your email (optional)</label>
        <input
          className="input"
          name="email"
          value={answerForm.email}
          onChange={handleAnswerChange}
        />
        <div style={{ height: 10 }} />

        <label className="label">Your answer</label>
        <textarea
          className="textarea"
          name="text"
          value={answerForm.text}
          onChange={handleAnswerChange}
        />
        <div style={{ height: 12 }} />

        <label className="label">References</label>
        <textarea
          className="textarea"
          name="references"
          value={answerForm.references}
          onChange={handleAnswerChange}
          placeholder="Link, book, documentation..."
        />
        <div style={{ height: 12 }} />

        <button type="submit" className="btn">
          Post Answer
        </button>
      </form>
    </section>
  );
};

export default QuestionDetails;
