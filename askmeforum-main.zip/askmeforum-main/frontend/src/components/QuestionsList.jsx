const QuestionsList = ({
  questions,
  categoryFilter,
  setCategoryFilter,
  categoriesForFilter,

  typeFilter,
  settypeFilter,
  typesForFilter,

  openQuestion,
  deleteQuestion,
  editQuestion,
}) => {
  return (
    <>
      {/* ================= LISTA E PYETJEVE ================= */}
      <section className="card">
        <h2 className="section-title">All Questions</h2>

        <label className="label">Filter by category</label>
        <select
          className="select"
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
        >
          {categoriesForFilter.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}

        
        </select>
      </section>

   {/* ================= LISTA per type ================= */}
      <section className="card">
        <h2 className="section-title">All Types</h2>

        <label className="label">Filter by types</label>
       <select
  className="select"
  value={typeFilter}
  onChange={(e) => settypeFilter(e.target.value)}
>
  {typesForFilter.map((t) => (
    <option key={t} value={t}>
      {t}
    </option>
  ))}


        
        </select>
      </section>



      <section>
        <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
          {questions.map((q) => (
            <li key={q.id} className="q-item" style={{ marginBottom: 14 }}>
              <h3>{q.title}</h3>

              <p className="small" style={{ marginTop: -2, marginBottom: 8 }}>
                {q.description}
              </p>

              <div className="q-meta">
                Category: {q.category} | Type: {q.type} | Author: {q.author} | Views: {q.views}
                {q.tags?.length ? (
                  <>
                    {" "}
                    | Tags:{" "}
                    {Array.isArray(q.tags) ? q.tags.join(", ") : q.tags}
                  </>
                ) : null}
              </div>

              {/* BUTTONS */}
              <div className="q-open">
                <button
                  className="btn"
                  onClick={() => openQuestion(q.id)}
                >
                  Open
                </button>


                <button
                  className="btn"
                  onClick={() => editQuestion(q.id)}
                  style={{ marginLeft: 6 }}
                >
                  Edit
                </button>

                <button
                  className="btn"
                  onClick={() => deleteQuestion(q.id)}
                  style={{
                    marginLeft: 6,
                    background: "red",
                    color: "white",
                  }}
                >
                  Delete
                </button>



              </div>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
};

export default QuestionsList;