function RegisterForm({
  registerForm,
  handleRegisterChange,
  registerUser,
}) {
  return (
    <section className="auth-card">
      <h3>Register</h3>

      <form className="auth-form" onSubmit={registerUser}>
        <input
          name="name"
          placeholder="Name"
          value={registerForm.name}
          onChange={handleRegisterChange}
        />

        <input
          name="surname"
          placeholder="Surname"
          value={registerForm.surname}
          onChange={handleRegisterChange}
        />

        <input
          type="email"
          name="email"
          placeholder="Email"
          value={registerForm.email}
          onChange={handleRegisterChange}
        />

        <input
          type="password"
          name="password"
          placeholder="Password"
          value={registerForm.password}
          onChange={handleRegisterChange}
        />

        <button type="submit" >  
          
          Register</button>
      </form>
    </section>
  );
}

export default RegisterForm;
