import { useState, useEffect } from "react";

function useAuth() {
  // 🔐 USER LOGGED IN
  const [currentUser, setCurrentUser] = useState(null);

  // ✅ Rikthen user-in nga localStorage kur hapet aplikacioni
  useEffect(() => {
    const savedUser = localStorage.getItem("user");

    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser));
    }
  }, []);
  // [] → ekzekutohet vetëm 1 herë kur komponenti mount-ohet

  // 📝 REGISTER FORM STATE
  const [registerForm, setRegisterForm] = useState({
    name: "",
    surname: "",
    email: "",
    password: "",
  });

  // 🔑 LOGIN FORM STATE
  const [loginForm, setLoginForm] = useState({
    email: "",
    password: "",
  });

  // 📢 AUTH MESSAGE
  const [authMsg, setAuthMsg] = useState("");

  /* ---------------- HANDLERS ---------------- */

  // Përditëson vetëm fushën që po ndryshohet
  const handleRegisterChange = (e) => {
    setRegisterForm({
      ...registerForm,
      [e.target.name]: e.target.value,
    });
  };

  const handleLoginChange = (e) => {
    setLoginForm({
      ...loginForm,
      [e.target.name]: e.target.value,
    });
  };

  /* ---------------- ACTIONS ---------------- */

  const registerUser = (e) => {
    e.preventDefault();

    console.log("REGISTER DATA:", registerForm);

    // Ruan user-in në localStorage
    localStorage.setItem("user", JSON.stringify(registerForm));

    // Opsionale: e logon direkt pas regjistrimit
    //setCurrentUser(registerForm);

    setAuthMsg("Registered successfully");



  };

  const loginUser = (e) => {
    e.preventDefault();

    const savedUser = JSON.parse(localStorage.getItem("user"));

    if (
      savedUser &&
      savedUser.email === loginForm.email &&
      savedUser.password === loginForm.password
    )
    
    {
      setCurrentUser(savedUser);
      setAuthMsg("");
    } else {
      setAuthMsg("Wrong email or password");
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem("user");
  };

  return {
    currentUser,
    registerForm,
    loginForm,
    authMsg,
    handleRegisterChange,
    handleLoginChange,
    registerUser,
    loginUser,
    logout,
  };
}

export default useAuth;
